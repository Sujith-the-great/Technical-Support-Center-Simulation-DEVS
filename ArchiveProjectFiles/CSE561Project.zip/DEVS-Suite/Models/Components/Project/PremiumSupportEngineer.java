package Components.Project;

import java.awt.Color;

import GenCol.entity;
import model.modeling.message;
import view.modeling.ViewableAtomic;

public class PremiumSupportEngineer extends ViewableAtomic {
	// graphics capability
	protected entity caseDetails;
	protected double processing_time;

	public PremiumSupportEngineer() {
		this("PremiumSupportEngineer", 10);
	}

	public PremiumSupportEngineer(String name, double Processing_time) {
		super(name);
		addInport("inLevelIII");
		addOutport("resolvedLevelIII");
		addInport("none"); // allows testing for null input
							// which should cause only "continue"
		processing_time = Processing_time;
		addTestInput("in", new entity("job1"));
		addTestInput("in", new entity("job2"), 20);
		addTestInput("none", new entity("job"));
		
		setBackgroundColor(Color.gray);
	}

	public void initialize() {
		phase = "passive";
		sigma = INFINITY;
		caseDetails = new entity("job");
		super.initialize();
	}

	public void deltext(double e, message x) {
		Continue(e);
//		It is because of all the simulators has to be executed. What is the minimum of nextTN of these three atomic models
//		

//		System.out.println("The elapsed time of the processor is" + e);
//		System.out.println("*****************************************");
//		System.out.println("external-Phase before: "+phase);
		
		
			
		if (phaseIs("passive"))
			for (int i = 0; i < x.getLength(); i++)
				if (messageOnPort(x, "inLevelIII", i)) {
					caseDetails = x.getValOnPort("inLevelIII", i);
					holdIn("busy", 10);
//					System.out.println("processing tiem of proc is"
//							+ processing_time);
				}
		
//		System.out.println("external-Phase after: "+phase);
	}

	public void deltint() {
//		System.out.println("Internal-Phase before: "+phase);
		passivate();
		caseDetails = new entity("none");
//		System.out.println("Internal-Phase after: "+phase);
	}

	public void deltcon(double e, message x) {
//		System.out.println("confluent");
		deltint();
		deltext(0, x);
	}

	public message out() {
		message m = new message();
		if (phaseIs("busy")) {
			m.add(makeContent("resolvedLevelIII", caseDetails));
		}
		return m;
	}

	public void showState() {
		super.showState();
		// System.out.println("job: " + job.getName());
	}

	public String getTooltipText() {
		return super.getTooltipText() + "\n" + "job: " + caseDetails.getName();
	}
}