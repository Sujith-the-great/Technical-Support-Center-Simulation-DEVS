package Components.Project;

import java.awt.Color;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import GenCol.*;

//import GenCol.entity;
import model.modeling.message;
import view.modeling.ViewableAtomic;

public class TechnicalSupportEngineer extends ViewableAtomic {
	// of atomic due to its
	// graphics capability
	protected entity caseDetails;
	protected double processing_time;
	protected double clock;
	protected HashMap<Integer, String> errorSolutions;
	protected int errorCode;
	protected Queue<entity> casesQueue;
	protected Map arrived;
	
	public TechnicalSupportEngineer() {
		this("TechnicalSupportEngineer", 10);
	}

	public TechnicalSupportEngineer(String name, double Processing_time) {
		super(name);
		addInport("inLevelI");
		addOutport("escalateLevelI");
		addOutport("resolvedLevelI");
		addInport("none"); // allows testing for null input
							// which should cause only "continue"
		processing_time = Processing_time;
		//addTestInput("in", new entity("job1"));
		//addTestInput("in", new entity("job2"), 20);
		//addTestInput("none", new entity("job"));
		addTestInput("inLevelI",new entity("customerCase 3 5 Michael 117 Performance-problems Amazon.com false false false 0.0 0.0 0.0"));
		addTestInput("inLevelI",new entity("customerCase 1 2 Sujith 102 UI-Not-showing-up Amazon.com false false false 0.0 0.0 0.0"));
		addTestInput("inLevelI",new entity("customerCase 4 1 AxelLopez 119 Account-management issues AWS false false false 0.0 0.0 0.0"));
		addTestInput("inLevelI",new entity("customerCase 5 3 Shreyansh 121 Recommendation-failures Amazon.com false false false 0.0 0.0 0.0"));
		addTestInput("inLevelI",new entity("customerCase 2 4 LockheedMartin 110 Browser-Compatibility-issues Amazon.com false false false 0.0 0.0 0.0"));
		errorSolutions = new HashMap<>();
		casesQueue = new LinkedList<>();
		arrived = new HashMap();
		clock = 0;
		processing_time=10;
		
		setBackgroundColor(Color.GREEN);
	}

	public void initialize() {
		phase = "passive";
		sigma = INFINITY;
		caseDetails = new entity("caseDetails");
		preLoadTheInternalDatabase();
		super.initialize();
	}
	
	public void preLoadTheInternalDatabase() {
		errorSolutions.put(100, "Reboot your computer to fix error 100");  
		errorSolutions.put(101, "Reinstall the application to fix error 101");
		errorSolutions.put(102, "Clear cache and cookies to fix error 102");
		errorSolutions.put(103, "Check internet connectivity to fix error 103");
		errorSolutions.put(104, "Update network drivers to fix error 104");
		errorSolutions.put(105, "Error 150 requires a software update");
		errorSolutions.put(106, "Free up disk space to fix error 160");
		errorSolutions.put(107, "Check file permissions to allow access");  
		errorSolutions.put(108, "Contact administrator to fix permission issue");
		errorSolutions.put(109, "Rollback recent changes to fix error 190");
		errorSolutions.put(110, "Critical error, contact tech support");
		
	}

	public void deltext(double e, message x) {
		Continue(e);
		clock = clock + e;
//		It is because of all the simulators has to be executed. What is the minimum of nextTN of these three atomic models
//		

//		System.out.println("The elapsed time of the processor is" + e);
//		System.out.println("*****************************************");
//		System.out.println("external-Phase before: "+phase);
		if (phaseIs("passive"))
			for (int i=0; i < x.getLength(); i++) {
				if (messageOnPort(x,"inLevelI",i)) {
					caseDetails = x.getValOnPort("inLevelI",i);
					arrived.put(caseDetails.getName(),new doubleEnt(clock));
					String[] parts = caseDetails.toString().trim().split(" ");
					errorCode = Integer.parseInt(parts[4].toString());
					holdIn("busy", 10);
				}
			}
		else if (phaseIs("busy"))
			for (int i=0; i < x.getLength(); i++) {
				if (messageOnPort(x,"inLevelI",i)) {
					arrived.put(x.getValOnPort("inLevelI",i).getName(),new doubleEnt(clock));
					casesQueue.add(x.getValOnPort("inLevelI",i));
					
				}
			}
		
		
		
		/*
			
		if (phaseIs("passive"))
			for (int i = 0; i < x.getLength(); i++)
				if (messageOnPort(x, "inLevelI", i)) {
					caseDetails = x.getValOnPort("inLevelI", i);
					String[] parts = caseDetails.toString().trim().split(" ");
					errorCode = Integer.parseInt(parts[4].toString());
					holdIn("busy", 10);
//					System.out.println("processing tiem of proc is"
//							+ processing_time);
				}
		 */
//		System.out.println("external-Phase after: "+phase);
	}

	public void deltint() {
//		System.out.println("Internal-Phase before: "+phase);
		clock = clock + sigma;
		
		if (!casesQueue.isEmpty()) {
			caseDetails = casesQueue.remove();
			String[] parts = caseDetails.toString().trim().split(" ");
			errorCode = Integer.parseInt(parts[4].toString());
			holdIn("busy", 10);
		}
		else
		{
			passivate();
			caseDetails = new entity("none");
		}
		
		/*
		passivate();
		caseDetails = new entity("none");
		*/
//		System.out.println("Internal-Phase after: "+phase);
	}

	public void deltcon(double e, message x) {
//		System.out.println("confluent");
		deltint();
		deltext(0, x);
	}

	public message out() {
		message m = new message();
		String[] parts = caseDetails.toString().trim().split(" ");
		double case_ta_time = clock-((doubleEnt)((entity)arrived.get(caseDetails.getName()))).getv()+processing_time;
		caseDetails = new entity(parts[0].trim()+" "+parts[1].trim()+" "+parts[2].trim()+" "+
                                 parts[3].trim()+" "+parts[4].trim()+" "+parts[5].trim()+" "+
	                             parts[6].trim()+" "+"true"+" "+parts[8].trim()+" "+parts[9].trim()+" "+
	                             case_ta_time+" "+parts[11].trim()+" "+parts[12].trim());
		if (phaseIs("busy")) {
			if(errorSolutions.containsKey(errorCode)) {
				System.out.println("The case has been resolved by Level- I");
				m.add(makeContent("resolvedLevelI", new entity(caseDetails.toString()+" "+"TSE")));
			}
			else {
				System.out.println("The case has been escalated to Level- II");
				m.add(makeContent("escalateLevelI",caseDetails));
			}
		}
		return m;
	}

	public void showState() {
		super.showState();
		// System.out.println("job: " + job.getName());
	}

	public String getTooltipText() {
		return super.getTooltipText() + "\n" + "job: " + caseDetails.getName();
	}
}
